#!/bin/sh
#
PATH=$PATH:/usr/X11/bin:/usr/openwin/bin;export PATH
EDITOR=vi;export EDITOR
vncserver -geometry 2500x1375
#vncserver -geometry 1880x1175
#vncserver -geometry 1280x1024
