/opt/netscape/server4/https-williams.Aus.Sun.COM/stop
/opt/netscape/server4/https-williams.Aus.Sun.COM/start
