/                 10
/abe              10
/home              5
/em                2
/apps              5
/exigen           20
/exint             5
/exportal          5
/unibatch          5
/u01/app/oracle    2
/var/goe/prod/wls  2
/var/goe/prod/batch  5
/var/goe/prod/other  2
/var/goe/prod/tuxapp 2
 