#!/usr/bin/bash
cat ~/.signature.html
