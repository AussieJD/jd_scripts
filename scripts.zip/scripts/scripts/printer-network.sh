sudo ifconfig en0 129.158.93.20 alias
